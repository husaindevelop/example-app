<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    <?php 

?>    
    </body>
</html>
<?php /**PATH C:\wamp\www2\example-app\resources\views/newpage.blade.php ENDPATH**/ ?>