<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    <table class="table">
<tr><td><a href="/list" style="color:black">List</a></td></tr>
<tr><td><a href="/add" style="color:black">Add</a></td></tr>
<tr><td><a href="/edit/?id=0" style="color:black">Edit</a></td></tr>
<tr><td><a href="/view" style="color:black">View</a></td></tr>
<tr><td><a href="/delete" style="color:black">Delete</a></td></tr>
    
</table>    
    </body>
</html>
